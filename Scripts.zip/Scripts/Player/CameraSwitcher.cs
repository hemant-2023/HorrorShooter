using UnityEngine;

public class CameraSwitcher : MonoBehaviour
{
    public Camera firstPersonCamera;   // Assign your FPP camera (child of player)
    public Camera topDownCamera;       // Assign your top-down camera in inspector

    private bool isTopDown = false;

    void Start()
    {
        // Ensure only one camera is active at start
        firstPersonCamera.enabled = true;
        topDownCamera.enabled = false;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E)) // Right-click
        {
            isTopDown = !isTopDown;

            firstPersonCamera.enabled = !isTopDown;
            topDownCamera.enabled = isTopDown;

            // Optional: lock/unlock mouse
            Cursor.lockState = isTopDown ? CursorLockMode.None : CursorLockMode.Locked;
            Cursor.visible = isTopDown;
        }
    }
}
